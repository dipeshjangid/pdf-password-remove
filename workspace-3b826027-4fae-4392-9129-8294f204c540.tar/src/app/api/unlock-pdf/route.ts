import { NextRequest, NextResponse } from "next/server";
import { execFile } from "child_process";
import { writeFile, readFile, mkdtemp } from "fs/promises";
import { tmpdir } from "os";
import path from "path";

export const runtime = "nodejs";

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

// Common passwords list for brute-force (most frequently used weak passwords)
const COMMON_PASSWORDS = [
  "", "password", "123456", "12345678", "1234", "12345", "111111", "123123",
  "admin", "letmein", "welcome", "monkey", "master", "qwerty", "abc123",
  "login", "princess", "dragon", "football", "shadow", "sunshine", "trustno1",
  "iloveyou", "1q2w3e4r", "654321", "password1", "password123", "123456789",
  "1234567890", "1234567", "123321", "666666", "888888", "123qwe", "test",
  "test123", "pass", "pass123", "root", "toor", "admin123", "guest",
  "default", "123", "1", "123abc", "abc", "abcdef", "abcd1234", "000000",
  "1111", "2222", "3333", "4444", "5555", "6666", "7777", "8888", "9999",
  "aaaaaa", "qwerty123", "password!", "P@ssw0rd", "p@ssword", "letmein123",
  "welcome1", "admin@123", "user", "user123", "demo", "demo123", "temp",
  "temp123", "sample", "1234qwer", "qwer1234", "asdfgh", "zxcvbn",
  "asdf", "zxcv", "1234abcd", "secret", "secret123", "passw0rd", "changeme",
  "Pa55word", "Passw0rd", "love", "god", "sex", "money", "freedom",
  "nothing", "baseball", "starwars", "solo", "mustang", "access", "buster",
  "jordan", "harley", "ranger", "thomas", "robert", "hockey", "ranger",
  "daniel", "zxcvbnm", "0987654321", "121212", "abc1234", "password12",
  "aaaaaaaa", "qazwsx", "open", "office", "pdf", "document", "file",
  "unlock", "secure", "security", "private", " confidential",
];

function runQpdf(args: string[]): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    execFile("qpdf", args, { maxBuffer: 10 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        reject(new Error(stderr || error.message));
      } else {
        resolve(stdout);
      }
    });
  });
}

async function tryUnlockWithPassword(
  inputPath: string,
  outputPath: string,
  password: string
): Promise<boolean> {
  const args: string[] = [];
  if (password.length > 0) {
    args.push(`--password=${password}`);
  }
  args.push("--decrypt", "--linearize", inputPath, outputPath);
  try {
    await runQpdf(args);
    // Verify output is valid PDF
    const output = await readFile(outputPath);
    return output.slice(0, 5).toString() === "%PDF-";
  } catch {
    return false;
  }
}

export async function POST(request: NextRequest) {
  let tempDir: string | null = null;

  try {
    const formData = await request.formData();
    const pdfFile = formData.get("pdf");
    const password = (formData.get("password") as string) || "";
    const mode = (formData.get("mode") as string) || "known"; // "known" or "forgot"

    // Validate file
    if (!pdfFile || !(pdfFile instanceof File)) {
      return NextResponse.json({ error: "No PDF file provided" }, { status: 400 });
    }

    if (pdfFile.type !== "application/pdf" && !pdfFile.name.endsWith(".pdf")) {
      return NextResponse.json({ error: "Only PDF files are supported" }, { status: 400 });
    }

    if (pdfFile.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: "File size exceeds the 50MB limit" }, { status: 400 });
    }

    if (pdfFile.size === 0) {
      return NextResponse.json({ error: "The uploaded file is empty" }, { status: 400 });
    }

    // Create a temporary directory
    tempDir = await mkdtemp(path.join(tmpdir(), "pdf-unlock-"));
    const inputPath = path.join(tempDir, "input.pdf");
    const outputPath = path.join(tempDir, "output.pdf");

    // Write the uploaded file to disk
    const fileBytes = Buffer.from(await pdfFile.arrayBuffer());
    await writeFile(inputPath, fileBytes);

    // Clean up helper
    const cleanup = async () => {
      try {
        if (tempDir) {
          const { rm } = await import("fs/promises");
          await rm(tempDir, { recursive: true, force: true });
        }
      } catch {}
    };

    // --- MODE: User knows the password ---
    if (mode === "known") {
      if (!password.trim()) {
        await cleanup();
        return NextResponse.json(
          { error: "Please enter the PDF password, or switch to 'I forgot password' mode." },
          { status: 400 }
        );
      }

      const success = await tryUnlockWithPassword(inputPath, outputPath, password.trim());

      if (!success) {
        await cleanup();
        return NextResponse.json(
          { error: "Incorrect password. Please check the password and try again." },
          { status: 400 }
        );
      }

      const unlockedPdfBytes = await readFile(outputPath);
      await cleanup();

      return new NextResponse(unlockedPdfBytes, {
        status: 200,
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `attachment; filename="unlocked_${pdfFile.name.replace(/\.pdf$/i, "")}.pdf"`,
          "Content-Length": unlockedPdfBytes.length.toString(),
        },
      });
    }

    // --- MODE: Forgot password ---
    // Step 1: Try without any password (works for owner-password-only PDFs)
    const noPassSuccess = await tryUnlockWithPassword(inputPath, outputPath, "");
    if (noPassSuccess) {
      const unlockedPdfBytes = await readFile(outputPath);
      await cleanup();
      return new NextResponse(unlockedPdfBytes, {
        status: 200,
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `attachment; filename="unlocked_${pdfFile.name.replace(/\.pdf$/i, "")}.pdf"`,
          "Content-Length": unlockedPdfBytes.length.toString(),
        },
      });
    }

    // Step 2: Try common passwords
    const triedPasswords: string[] = [];
    for (const commonPass of COMMON_PASSWORDS) {
      if (commonPass === "") continue; // Already tried empty password
      triedPasswords.push(commonPass);
      const success = await tryUnlockWithPassword(inputPath, outputPath, commonPass);
      if (success) {
        const unlockedPdfBytes = await readFile(outputPath);
        await cleanup();
        return new NextResponse(unlockedPdfBytes, {
          status: 200,
          headers: {
            "Content-Type": "application/pdf",
            "Content-Disposition": `attachment; filename="unlocked_${pdfFile.name.replace(/\.pdf$/i, "")}.pdf"`,
            "Content-Length": unlockedPdfBytes.length.toString(),
            "X-Found-Password": commonPass,
          },
        });
      }
    }

    // All attempts failed
    await cleanup();
    return NextResponse.json(
      {
        error:
          "Could not unlock this PDF. The password is too strong or this PDF uses encryption that cannot be bypassed. If you remember the password, try the 'I know the password' option.",
        tried: triedPasswords.length + 1, // +1 for empty password attempt
      },
      { status: 400 }
    );
  } catch (error) {
    try {
      if (tempDir) {
        const { rm } = await import("fs/promises");
        await rm(tempDir, { recursive: true, force: true });
      }
    } catch {}

    console.error("PDF unlock error:", error);
    const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json({ error: `Server error: ${errorMessage}` }, { status: 500 });
  }
}