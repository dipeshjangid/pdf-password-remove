"use client";

import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  FileUp,
  Lock,
  Unlock,
  Download,
  Shield,
  Zap,
  Eye,
  EyeOff,
  X,
  CheckCircle2,
  AlertCircle,
  FileText,
  Trash2,
  Loader2,
  KeyRound,
  Brain,
  Info,
} from "lucide-react";
import { toast } from "sonner";

interface UploadedFile {
  file: File;
  id: string;
  status: "idle" | "processing" | "done" | "error";
  progress: number;
  resultBlob?: Blob;
  resultUrl?: string;
  error?: string;
  foundPassword?: string;
}

type UnlockMode = "known" | "forgot";

export default function Home() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [mode, setMode] = useState<UnlockMode>("forgot");
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(
    (incomingFiles: FileList | File[]) => {
      const fileArray = Array.from(incomingFiles);
      const pdfFiles = fileArray.filter(
        (f) => f.type === "application/pdf" || f.name.endsWith(".pdf")
      );

      if (pdfFiles.length === 0) {
        toast.error("Only PDF files are supported");
        return;
      }

      const newFiles: UploadedFile[] = pdfFiles.map((file) => ({
        file,
        id: crypto.randomUUID(),
        status: "idle",
        progress: 0,
      }));

      setFiles((prev) => [...prev, ...newFiles]);

      if (pdfFiles.length < fileArray.length) {
        toast.warning(
          `${fileArray.length - pdfFiles.length} non-PDF file(s) were skipped`
        );
      }
    },
    []
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);
      if (e.dataTransfer.files.length > 0) {
        handleFiles(e.dataTransfer.files);
      }
    },
    [handleFiles]
  );

  const removeFile = useCallback((id: string) => {
    setFiles((prev) => {
      const file = prev.find((f) => f.id === id);
      if (file?.resultUrl) {
        URL.revokeObjectURL(file.resultUrl);
      }
      return prev.filter((f) => f.id !== id);
    });
  }, []);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const processFiles = async () => {
    if (files.length === 0) {
      toast.error("Please upload a PDF file first");
      return;
    }

    if (mode === "known" && !password.trim()) {
      toast.error("Please enter the PDF password");
      return;
    }

    setIsProcessing(true);

    const idleFiles = files.filter((f) => f.status === "idle" || f.status === "error");

    if (idleFiles.length === 0) {
      toast.info("All files have already been processed");
      setIsProcessing(false);
      return;
    }

    for (const fileItem of idleFiles) {
      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileItem.id ? { ...f, status: "processing", progress: 5 } : f
        )
      );

      try {
        const formData = new FormData();
        formData.append("pdf", fileItem.file);
        formData.append("password", password);
        formData.append("mode", mode);

        setFiles((prev) =>
          prev.map((f) =>
            f.id === fileItem.id ? { ...f, progress: 15 } : f
          )
        );

        const response = await fetch("/api/unlock-pdf", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to unlock PDF");
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const foundPass = response.headers.get("X-Found-Password");

        setFiles((prev) =>
          prev.map((f) =>
            f.id === fileItem.id
              ? {
                  ...f,
                  status: "done",
                  progress: 100,
                  resultBlob: blob,
                  resultUrl: url,
                  foundPassword: foundPass || undefined,
                }
              : f
          )
        );

        if (foundPass) {
          toast.success(`Password found: "${foundPass}" — PDF unlocked!`);
        } else if (mode === "forgot") {
          toast.success(`"${fileItem.file.name}" unlocked without password!`);
        } else {
          toast.success(`"${fileItem.file.name}" unlocked successfully!`);
        }
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : "Unknown error occurred";
        setFiles((prev) =>
          prev.map((f) =>
            f.id === fileItem.id
              ? { ...f, status: "error", progress: 0, error: errorMessage }
              : f
          )
        );
        toast.error(`Failed: ${errorMessage}`);
      }
    }

    setIsProcessing(false);
  };

  const downloadFile = (fileItem: UploadedFile) => {
    if (!fileItem.resultUrl) return;
    const link = document.createElement("a");
    link.href = fileItem.resultUrl;
    const originalName = fileItem.file.name.replace(/\.pdf$/i, "");
    link.download = `${originalName}_unlocked.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    const doneFiles = files.filter((f) => f.status === "done" && f.resultUrl);
    doneFiles.forEach((f, index) => {
      setTimeout(() => downloadFile(f), index * 300);
    });
  };

  const resetAll = () => {
    files.forEach((f) => {
      if (f.resultUrl) URL.revokeObjectURL(f.resultUrl);
    });
    setFiles([]);
    setPassword("");
  };

  const completedCount = files.filter((f) => f.status === "done").length;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-emerald-50/50 via-white to-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-lg">
        <div className="mx-auto max-w-5xl flex h-16 items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-600 text-white">
              <Unlock className="h-5 w-5" />
            </div>
            <span className="text-lg font-bold tracking-tight text-foreground">
              PDF Unlock
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">100% Secure & Private</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 pt-12 pb-8 md:pt-20 md:pb-12">
            <div className="flex flex-col items-center text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-foreground leading-tight">
                  Remove PDF Password
                  <br />
                  <span className="text-emerald-600">Instantly & Free</span>
                </h1>
              </motion.div>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="mt-4 max-w-2xl text-base sm:text-lg text-muted-foreground"
              >
                Password bhool gaye? Koi baat nahi! Upload karo, hum unlock karenge.
                <br className="hidden sm:block" />
                Know the password? Enter it for instant unlock.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mt-8 flex flex-wrap justify-center gap-3 text-sm"
              >
                <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full">
                  <Zap className="h-4 w-4" />
                  <span>Fast Processing</span>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full">
                  <Brain className="h-4 w-4" />
                  <span>Password Bhullao? No Problem</span>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full">
                  <Shield className="h-4 w-4" />
                  <span>No Data Stored</span>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Upload Section */}
        <section className="mx-auto max-w-3xl px-4 sm:px-6 pb-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            {/* Drag & Drop Area */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`
                relative cursor-pointer rounded-2xl border-2 border-dashed p-8 sm:p-12
                transition-all duration-200 ease-out
                ${
                  isDragging
                    ? "border-emerald-500 bg-emerald-50/80 scale-[1.01]"
                    : "border-muted-foreground/25 hover:border-emerald-400 hover:bg-emerald-50/30"
                }
              `}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,application/pdf"
                multiple
                onChange={(e) => e.target.files && handleFiles(e.target.files)}
                className="hidden"
              />

              <div className="flex flex-col items-center text-center">
                <motion.div
                  animate={isDragging ? { scale: 1.1, y: -5 } : { scale: 1, y: 0 }}
                  className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600"
                >
                  <FileUp className="h-8 w-8" />
                </motion.div>

                <p className="text-base sm:text-lg font-semibold text-foreground">
                  {isDragging
                    ? "Drop your PDF files here"
                    : "Drag & drop your PDF files here"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  or click to browse files
                </p>
                <p className="mt-3 text-xs text-muted-foreground/70">
                  Supports PDF files up to 50MB each
                </p>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Mode Toggle + Password + Action Section */}
        <AnimatePresence>
          {files.length > 0 && (
            <motion.section
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mx-auto max-w-3xl px-4 sm:px-6 pb-6 overflow-hidden"
            >
              <Card className="border-emerald-200/60 bg-white shadow-sm">
                <CardContent className="p-4 sm:p-6 space-y-4">
                  {/* Mode Toggle */}
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      How do you want to unlock?
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setMode("forgot")}
                        className={`
                          relative flex items-start gap-3 rounded-xl border-2 p-4 text-left transition-all duration-200
                          ${
                            mode === "forgot"
                              ? "border-emerald-500 bg-emerald-50/80 shadow-sm"
                              : "border-muted hover:border-emerald-300 hover:bg-emerald-50/30"
                          }
                        `}
                      >
                        <div
                          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                            mode === "forgot"
                              ? "bg-emerald-600 text-white"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          <Brain className="h-4.5 w-4.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p
                            className={`text-sm font-semibold ${
                              mode === "forgot" ? "text-emerald-800" : "text-foreground"
                            }`}
                          >
                            I Forgot My Password
                          </p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Tool will try to unlock automatically (owner password removal + common passwords)
                          </p>
                        </div>
                        {mode === "forgot" && (
                          <div className="absolute top-2 right-2 h-5 w-5 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                          </div>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => setMode("known")}
                        className={`
                          relative flex items-start gap-3 rounded-xl border-2 p-4 text-left transition-all duration-200
                          ${
                            mode === "known"
                              ? "border-emerald-500 bg-emerald-50/80 shadow-sm"
                              : "border-muted hover:border-emerald-300 hover:bg-emerald-50/30"
                          }
                        `}
                      >
                        <div
                          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                            mode === "known"
                              ? "bg-emerald-600 text-white"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          <KeyRound className="h-4.5 w-4.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p
                            className={`text-sm font-semibold ${
                              mode === "known" ? "text-emerald-800" : "text-foreground"
                            }`}
                          >
                            I Know the Password
                          </p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Enter the password for instant unlock
                          </p>
                        </div>
                        {mode === "known" && (
                          <div className="absolute top-2 right-2 h-5 w-5 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                          </div>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Password Input (only in "known" mode) */}
                  <AnimatePresence>
                    {mode === "known" && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <label className="text-sm font-medium text-foreground flex items-center gap-1.5 mb-2">
                          <Lock className="h-4 w-4 text-emerald-600" />
                          PDF Password
                        </label>
                        <div className="relative">
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter the PDF password..."
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="pr-10 h-11"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Info for "forgot" mode */}
                  <AnimatePresence>
                    {mode === "forgot" && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="flex items-start gap-2.5 rounded-lg bg-amber-50 border border-amber-200 p-3">
                          <Info className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                          <div className="text-xs text-amber-800 leading-relaxed">
                            <p className="font-semibold mb-0.5">Kaise kaam karta hai?</p>
                            <ul className="list-disc list-inside space-y-0.5">
                              <li>Pehle bina password ke try karega (owner password removal)</li>
                              <li>Phir 100+ common passwords try karega (123456, password, admin, etc.)</li>
                              <li>Agar weak password hai toh unlock ho jayega!</li>
                            </ul>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      onClick={processFiles}
                      disabled={isProcessing || files.every((f) => f.status === "done")}
                      className="h-11 bg-emerald-600 hover:bg-emerald-700 text-white flex-1 sm:flex-initial px-6"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          {mode === "forgot" ? "Unlocking..." : "Unlocking..."}
                        </>
                      ) : (
                        <>
                          <Unlock className="h-4 w-4 mr-2" />
                          {mode === "forgot"
                            ? `Unlock (No Password)`
                            : `Unlock PDF${files.length > 1 ? "s" : ""}`}
                        </>
                      )}
                    </Button>
                    {completedCount > 0 && (
                      <Button
                        onClick={downloadAll}
                        variant="outline"
                        className="h-11 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.section>
          )}
        </AnimatePresence>

        {/* File List */}
        <AnimatePresence>
          {files.length > 0 && (
            <motion.section
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mx-auto max-w-3xl px-4 sm:px-6 pb-12"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-muted-foreground">
                    {files.length} file{files.length > 1 ? "s" : ""} uploaded
                  </p>
                  <button
                    onClick={resetAll}
                    className="text-sm text-muted-foreground hover:text-destructive flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Clear All
                  </button>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto pr-1 custom-scrollbar">
                  {files.map((fileItem) => (
                    <motion.div
                      key={fileItem.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                    >
                      <Card className="border overflow-hidden">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div
                              className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
                                fileItem.status === "done"
                                  ? "bg-emerald-100 text-emerald-600"
                                  : fileItem.status === "error"
                                  ? "bg-red-100 text-red-600"
                                  : fileItem.status === "processing"
                                  ? "bg-amber-100 text-amber-600"
                                  : "bg-muted text-muted-foreground"
                              }`}
                            >
                              {fileItem.status === "done" ? (
                                <CheckCircle2 className="h-5 w-5" />
                              ) : fileItem.status === "error" ? (
                                <AlertCircle className="h-5 w-5" />
                              ) : fileItem.status === "processing" ? (
                                <Loader2 className="h-5 w-5 animate-spin" />
                              ) : (
                                <FileText className="h-5 w-5" />
                              )}
                            </div>

                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">
                                {fileItem.file.name}
                              </p>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                {formatFileSize(fileItem.file.size)}
                                {fileItem.status === "done" && (
                                  <span className="text-emerald-600 ml-2">
                                    &bull; Unlocked
                                    {fileItem.foundPassword && (
                                      <span className="ml-1.5 font-medium text-amber-600">
                                        (password: &quot;{fileItem.foundPassword}&quot;)
                                      </span>
                                    )}
                                    {!fileItem.foundPassword && mode === "forgot" && (
                                      <span className="ml-1.5 font-medium text-emerald-700">
                                        (no password needed)
                                      </span>
                                    )}
                                  </span>
                                )}
                                {fileItem.status === "processing" && (
                                  <span className="text-amber-600 ml-2">
                                    &bull; {mode === "forgot" ? "Trying to unlock..." : "Processing..."}
                                  </span>
                                )}
                              </p>
                              {fileItem.error && (
                                <p className="text-xs text-red-500 mt-1">
                                  {fileItem.error}
                                </p>
                              )}
                              {(fileItem.status === "processing" ||
                                fileItem.status === "done") && (
                                <div className="mt-2">
                                  <Progress
                                    value={fileItem.progress}
                                    className="h-1.5"
                                  />
                                </div>
                              )}
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {fileItem.status === "done" && fileItem.resultUrl && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => downloadFile(fileItem)}
                                  className="h-8 px-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                                >
                                  <Download className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => removeFile(fileItem.id)}
                                className="h-8 px-2 text-muted-foreground hover:text-destructive"
                                disabled={fileItem.status === "processing"}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full rounded-xl border-2 border-dashed border-muted-foreground/15 p-3 text-sm text-muted-foreground hover:border-emerald-400 hover:text-emerald-600 transition-all duration-200"
                >
                  + Add more files
                </button>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* Hero Image Section */}
        <section className="mx-auto max-w-5xl px-4 sm:px-6 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="relative overflow-hidden rounded-2xl border bg-white shadow-lg"
          >
            <img
              src="/hero-pdf.png"
              alt="PDF Password Removal Illustration"
              className="w-full h-auto object-cover"
            />
          </motion.div>
        </section>

        {/* How It Works */}
        <section className="mx-auto max-w-5xl px-4 sm:px-6 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10"
          >
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
              How It Works
            </h2>
            <p className="mt-2 text-muted-foreground">
              Password yaad ho ya na ho — 2 simple steps
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                step: "1",
                icon: FileUp,
                title: "Upload PDF",
                description:
                  "Apna password-protected PDF upload karo. Multiple files bhi ek saath de sakte ho.",
              },
              {
                step: "2",
                icon: Unlock,
                title: "Auto Unlock or Enter Password",
                description:
                  'Password yaad nahi? "I Forgot Password" select karo — tool automatically try karega. Ya apna password enter karo for instant unlock.',
              },
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
              >
                <Card className="border-emerald-100 bg-white h-full hover:shadow-md transition-shadow duration-200">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-600 text-white font-bold text-sm">
                        {item.step}
                      </div>
                      <item.icon className="h-5 w-5 text-emerald-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground">
                      {item.title}
                    </h3>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-emerald-50/50 py-16">
          <div className="mx-auto max-w-5xl px-4 sm:px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-10"
            >
              <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
                Why Choose PDF Unlock?
              </h2>
              <p className="mt-2 text-muted-foreground">
                Sabse reliable free PDF password remover
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: Brain,
                  title: "Password Bhulao?",
                  description:
                    "Bina password ke unlock karne ki koshish karta hai. Owner password aur common passwords try karta hai.",
                },
                {
                  icon: Zap,
                  title: "Lightning Fast",
                  description:
                    "100+ passwords seconds mein try karta hai. Instant results milega.",
                },
                {
                  icon: FileText,
                  title: "Batch Processing",
                  description:
                    "Ek saath multiple PDF files upload aur unlock karo.",
                },
                {
                  icon: Shield,
                  title: "100% Secure",
                  description:
                    "Files server pe store nahi hoti. Process hote hi delete ho jaati hain.",
                },
              ].map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                >
                  <div className="text-center p-4">
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-sm mb-3 text-emerald-600">
                      <feature.icon className="h-6 w-6" />
                    </div>
                    <h3 className="text-sm font-semibold text-foreground">
                      {feature.title}
                    </h3>
                    <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mx-auto max-w-3xl px-4 sm:px-6 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10"
          >
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
              Frequently Asked Questions
            </h2>
          </motion.div>

          <div className="space-y-4">
            {[
              {
                question: "Password yaad nahi hai — kya unlock hoga?",
                answer:
                  'Haan! "I Forgot My Password" option select karo. Tool pehle bina password ke try karega (owner password wale PDFs directly unlock ho jaate hain). Phir 100+ common passwords automatically try karega. Agar password weak hai (jaise 123456, password, admin) toh unlock ho jayega!',
              },
              {
                question: "Kya yeh strong passwords bhi crack kar sakta hai?",
                answer:
                  'Nahi. Yeh tool sirf weak/common passwords try karta hai. Agar PDF mein strong password hai (jaise "Xy$9kL!m"), toh woh unlock nahi hoga. Aapko apna password yaad karna hoga aur "I Know the Password" option use karna hoga.',
              },
              {
                question: "Owner password aur User password mein kya fark hai?",
                answer:
                  'Owner password sirf restrictions lagata hai (print, copy, edit). User password PDF ko open karne ke liye hota hai. Yeh tool dono type ke passwords remove kar sakta hai.',
              },
              {
                question: "Kya meri files safe hain?",
                answer:
                  'Bilkul! Files process hote hi server se delete ho jaati hain. Hum koi data store nahi karte. Sab processing secure environment mein hoti hai.',
              },
              {
                question: "Yeh tool free hai?",
                answer:
                  'Haan, 100% free! Koi hidden charge nahi, koi watermark nahi. Unlimited files unlock karo.',
              },
            ].map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.7 + index * 0.05 }}
              >
                <Card className="border-muted">
                  <CardContent className="p-5">
                    <h3 className="text-sm font-semibold text-foreground mb-1.5">
                      {faq.question}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {faq.answer}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Unlock className="h-4 w-4 text-emerald-600" />
              <span className="font-medium text-foreground">PDF Unlock</span>
              <span>&copy; {new Date().getFullYear()}. All rights reserved.</span>
            </div>
            <p className="text-xs text-muted-foreground text-center">
              Files processed securely and never stored.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}