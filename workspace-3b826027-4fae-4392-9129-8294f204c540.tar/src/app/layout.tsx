import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PDF Password Remover - Unlock Your PDFs Instantly & Free",
  description: "Remove passwords from your PDF files instantly. Fast, secure, and 100% free online PDF unlocker tool. No installation required.",
  keywords: ["PDF password remover", "unlock PDF", "remove PDF password", "PDF unlocker", "free PDF tool", "online PDF"],
  authors: [{ name: "PDF Password Remover" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "PDF Password Remover - Unlock Your PDFs Instantly",
    description: "Remove passwords from your PDF files instantly. Fast, secure, and free.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
